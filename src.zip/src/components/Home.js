import react from "react";

function Home() {
    return (
        <div><h1>this is the homepage</h1></div>
    );
}

export default Home;