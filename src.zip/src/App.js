import logo from './logo.svg';
import './App.css';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";

import Header from './components/Header';
import Footer from './components/Footer';
import Home from './components/Home';
import Content from './components/Content';

function App() {
  return (
    <div className='website'>
      <Header />

      <Router>
        <>
          <Routes>
            <Route path="/Home" element={<Home />}></Route>
            <Route path="/Content" element={<Content />}></Route>
          </Routes>
        </>
      </Router >



      <Footer />
    </div >
  );
}

export default App;
